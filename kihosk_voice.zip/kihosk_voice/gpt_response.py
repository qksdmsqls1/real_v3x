# <주요 역할>
# 환경 변수 로드: .env 파일에서 OpenAI API 키를 불러옴
# GPT API 호출: 사용자가 입력한 질문(prompt)을 OpenAI API로 전송하고 응답을 반환

# 1. 모듈 임포트 및 API 키 로드
import os
import openai
from dotenv import load_dotenv

# .env 파일에서 API 키 불러오기
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")  # ← 여기 변수명 주의! .env에서 이 이름으로 불러와야 해

# 2. OpenAI API 키 설정
openai.api_key = api_key

# 3. GPT 응답 호출 함수: get_gpt_response(prompt)
def get_gpt_response(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # 또는 "gpt-4"
        messages=[
            {"role": "system", "content": "당신은 친절한 키오스크 안내원입니다."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content

# 4. 테스트 실행 (if name == "main")
if __name__ == "__main__":
    user_input = input("사용자 질문을 입력하세요: ")
    answer = get_gpt_response(user_input)
    print("🧠 GPT 응답:", answer)