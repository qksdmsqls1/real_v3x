# <주요 역할>
# 문자열을 음성으로 변환하여 출력: pyttsx3 라이브러리를 사용해 텍스트를 음성으로 읽어줌

# 1. 모듈 임포트 및 TTS 함수: speak(text)
import pyttsx3

def speak(text):
    engine = pyttsx3.init() # TTS 엔진 초기화
    engine.setProperty('rate', 180)  # 말하는 속도 (단위: words per minute 등)
    engine.setProperty('volume', 1.0)  # 볼륨 (범위: 0.0 ~ 1.0)
    engine.say(text)
    engine.runAndWait()

# 2. 테스트 실행 (if name == "main")
if __name__ == "__main__":
    speak("안녕하세요. 무엇을 도와드릴까요?")