# <주요 역할>
# 음성 녹음: 사용자의 음성을 5초 동안 녹음
# 녹음 파일 저장: 녹음된 데이터를 임시 WAV 파일로 저장
# Whisper로 음성 인식: 저장된 음성 파일을 Whisper 모델을 통해 텍스트로 변환
# GPT 요청 및 응답 처리: 인식된 텍스트를 GPT에 전달하여 응답을 받고, 그 응답을 음성으로 출력

# 1. 모듈 임포트 및 상수 설정
import sounddevice as sd # 마이크 입력을 받아 음성 녹음
import numpy as np # 녹음된 데이터의 배열 처리
import whisper # OpenAI의 Whisper 모델을 활용해 음성 인식 수행
import scipy.io.wavfile as wav # 녹음된 데이터를 WAV 파일로 저장할 때 사용
import tempfile # 임시 파일을 생성하여 저장
from gpt_response import get_gpt_response  # GPT 함수 불러오기
from text_to_speech import speak  # TTS 함수 불러오기

SAMPLE_RATE = 16000 # 녹음 품질 (Hz)
DURATION = 5 # 녹음 시간 (S)

# 2. 음성 녹음 함수: record_audio()
def record_audio():
    print("🎙 음성을 녹음하세요... (5초)")
    audio = sd.rec(int(DURATION * SAMPLE_RATE), samplerate=SAMPLE_RATE, channels=1, dtype='float32')
    sd.wait()
    print("✅ 녹음 완료!")
    return audio

# 3. 임시 WAV 파일 저장 함수: save_temp_wav(audio)
def save_temp_wav(audio):
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        wav.write(f.name, SAMPLE_RATE, (audio * 32767).astype(np.int16))
        return f.name
    
# 4. Whisper를 이용한 음성 인식 함수: transcribe(audio_path)
def transcribe(audio_path):
    model = whisper.load_model("base") # 필요한 경우 "small", "medium"으로 변경 가능
    result = model.transcribe(audio_path, language="ko")
    return result["text"]

# 5. 전체 흐름 처리 (main 블록)
if __name__ == "__main__":
    start_msg = '안녕하세요. 무엇을 도와드릴까요?'
    order_o = '주문이 완료되었습니다. 감사합니다.'
    order_x = '주문이 취소되었습니다.'
    order = 0 # 0은 주문 전, 1은 주문 시작
    vs_btn = True # vs_btn: voice start button
    
    if vs_btn == True:
        if order == 0:  # 주문 전
            print(f"🤖 GPT: {start_msg}")
            speak(start_msg)
            order = 1   # 주문 시작

        while True:
            audio = record_audio()              # 음성 녹음
            wav_path = save_temp_wav(audio)     # 녹음된 음성을 WAV 파일로 저장
            text = transcribe(wav_path)         # Whisper로 텍스트 변환
            print(f"📝 인식된 텍스트: {text}")

            if '주문 완료' in text or '주문 취소' in text:
                order = 0 # 주문 전으로 초기화
                if '주문 완료' in text:
                    print(f"🤖 GPT: {order_o}")
                    speak(order_o)
                else:
                    print(f"🤖 GPT: {order_x}")
                    speak(order_x)
                break

            # GPT에 텍스트 보내고 응답 받기
            gpt_answer = get_gpt_response(text)
            print(f"🤖 GPT: {gpt_answer}")

            # 음성으로 응답 읽기
            speak(gpt_answer)