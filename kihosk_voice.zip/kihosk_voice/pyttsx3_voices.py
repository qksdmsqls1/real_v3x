# 사용 가능한 음성 목록 조회

import pyttsx3

engine = pyttsx3.init()
voices = engine.getProperty('voices')
for idx, voice in enumerate(voices):
    print(f"Voice {idx}: {voice.name} - {voice.id}")
